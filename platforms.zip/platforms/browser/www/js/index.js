document.addEventListener('deviceready', function(){alert('device ready');}, false);
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    document.getElementById('deviceready').classList.add('ready');
}

function getPicture() {
    navigator.camera.getPicture(
        function(imageURI) {
            var image = document.getElementById('myImage');
            image.src = imageURI;
        },
        function(message) {
            alert('Failed because: ' + message);
        },
        {
            quality: 50,
            destinationType: Camera.DestinationType.FILE_URI
        }
    );
}