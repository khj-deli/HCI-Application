Hello,

Thank you for downloading Ethereal

NOTE: This font is FREE 100% FOR PERSONAL USE ONLY! But any donations are very appreciated. 

Paypal account for donation: https://paypal.me/amalyusup

Link to purchase full version and commercial license :
-> https://creativemarket.com/kereatype/7012712-Ethereal-Elegant-Serif-Family

Browse More Font:
-> https://creativemarket.com/kereatype

If you need a custom license please contact us at 
kereatype@gmail.com


Follow our Instagram for update: @kereatype

Thanks,
Kereatype