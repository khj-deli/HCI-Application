document.addEventListener('deviceready', function(){alert('device ready');}, false);
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    document.getElementById('deviceready').classList.add('ready');
}

function getPicture() {
    navigator.camera.getPicture(
        function(imageURI) {
            var image = document.getElementById('myImage');
            image.src = imageURI;
        },
        function(message) {
            alert('Failed because: ' + message);
        },
        {
            quality: 50,
            destinationType: Camera.DestinationType.FILE_URI
        }
    );
}

function goBack() {
    window.history.back(); // 이전 페이지로 이동
}
function scrollTo100px() {
    window.scrollBy(0, 100); // 수직 스크롤 방향으로 100px 아래로 스크롤
}

// 버튼 클릭 이벤트에 스크롤 함수 연결
var scrollButton = document.getElementById('scrollBtn');
scrollButton.addEventListener('click', scrollTo100px);

